﻿This project is based on visual studio 2019.

I implemented simulated annealing with using swapping two random tasks.
With checking if core meet the deadline and all cores has task, I validated the solution.
When the program runs, it will generate xml file with solution in folder ""test_cases" and show total laxity on console.
You can choose xml file path in main and writeXML function.

